package imagefilter;

public class ImageFilterPipeline {

  // zu ladende Bilddateien (z.B. "image01.png")
  private final String[] imageFiles;

  // geladenes Bild (== null wenn gerade keines verfügbar)
  double[][] sourceImage;

  // gefiltertes Bild (== null wenn gerade keines verfügbar)
  double[][] filteredImage;

  public ImageFilterPipeline(String[] imageFiles){
    this.imageFiles = imageFiles;
  }

  // Lädt die Bilddateien in imageFiles und stellt die Pixel in
  // sourceImage dem nächsten Schritt filterImages bereit
  private void loadImages( /* ... */ ){

  }

  // Übernimmt die Pixel in sourceImage, filtert sie und übergibt
  // sie über filteredImage an saveImages
  private void filterImages( /* ... */ ){

  }

  // Übernimmt die Pixel in filteredImage und speichert sie in
  // einer einer Bilddatei mit dem Präfix "filtered-"
  private void saveImages( /* ... */ ){

  }

  public void start(){
    /* Startet die Pipeline */

  }


  
}
