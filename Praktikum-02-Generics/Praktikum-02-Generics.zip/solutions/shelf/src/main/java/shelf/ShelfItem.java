package shelf;

public abstract class ShelfItem {



}
